import { useState, createContext } from "react";

export const RegisterContext = createContext();
