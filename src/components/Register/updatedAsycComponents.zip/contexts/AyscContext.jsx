import {  createContext } from "react";

export const AyscContext = createContext();
